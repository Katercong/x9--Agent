# x9-tk-creator-extension-2.2 — 交付包

## 包内容

```
bundle/
├── README.md                         本文件
├── extension/                        插件源文件 (可直接 chrome://extensions 加载)
│   ├── manifest.json
│   ├── x9_sw.js                      service worker 入口
│   ├── background.js                 storage 初始化 + sidePanel
│   ├── x9_relay.js                   X9 仪表盘心跳 + leads ingest
│   ├── shop_runner.js                Shop 状态机 + 详情循环 + 上传
│   ├── shop_collector.js             列表/详情解析 + 滚屏 + 点击
│   ├── shop_panel.js                 侧边栏 Shop UI 状态轮询
│   ├── contentScript.js              www.tiktok.com 老流程
│   ├── popup.js                      老流程 popup 逻辑
│   ├── popup.html / sidepanel.html   UI
│   ├── popup.css
│   ├── i18n_toggle.js                中英切换
│   ├── README.md                     原作者说明
│   └── x9-tk-creator-extension-2.2.zip   原始 zip (直接拖到 chrome 也行)
├── samples/                          上传 payload 样例
│   ├── 01_list_observation_sample.json     Shop 列表阶段
│   ├── 02_detail_observation_sample.json   Shop 详情阶段
│   ├── 03_launcher_heartbeat_sample.json   X9 心跳
│   ├── 04_x9_leads_ingest_sample.json      X9 leads (老流程)
│   └── fields_reference.md                 字段速查表 + 容量上限
└── docs/
    ├── WORKFLOW.md       端点 / 数据流 / 状态机 / 安装 / 排错
    └── TEST_GUIDE.md     真实环境小规模验证清单 (V1-V4)
```

## 三类上传, 一句话总结

| 通道 | 端点 | 频率 | payload 重点 |
|---|---|---|---|
| Shop 列表 | POST 127.0.0.1:8000/api/local/collector/observations | 每发现一条新 handle | 卡片字段 + 整行 HTML/可见文本 |
| Shop 详情 | 同上 | 每个详情页一条 | 整页 DOM (≤1.5M) + 可见文本 (≤300K) + 链接 |
| X9 心跳 | POST {base}/api/local/extension/launcher-heartbeat | 30 秒 + 状态变 | activeTab.url + counts + settings |

## 快速使用

1. 解压 extension/x9-tk-creator-extension-2.2.zip 到固定目录
2. 后端起来: 127.0.0.1:8000
3. chrome://extensions -> 开发者模式 -> 加载已解压
4. 登录 affiliate-us.tiktok.com/connection/creator
5. 点扩展图标 -> 🛒 任务数 N -> ▶ 开始
6. 跑完去 localhost:8000/ui/ 看数据

详细测试步骤看 docs/TEST_GUIDE.md。
