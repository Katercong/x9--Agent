# 测试指南 — 真实环境小规模验证

## 准备

1. 后端启动: 127.0.0.1:8000 (start_desktop.bat)
2. Chrome 加载 extension/ 目录 (chrome://extensions -> 加载已解压的扩展程序)
3. 登录 https://affiliate-us.tiktok.com/connection/creator

## 双 DevTools 抓包

### A. 列表页 DevTools (网页那边)
- F12 -> Network -> Preserve log
- Filter: `observations`, Fetch/XHR
- 用途: 肉眼对照 TikTok 自己请求的列表数据 (注意: 我们的 POST 不在这里, 在 service worker 那边)

### B. 扩展 service worker DevTools (关键)
- chrome://extensions -> TikTok Creator Lead Browser 卡片 -> "Service Worker" 链接
- 弹出 DevTools -> Console (看 [TSCLB-SW] / [TSCLB-CS] 日志)
- 切到 Network -> Preserve log -> Filter: `8000` (一次看 observations 和 launcher-heartbeat)

## 执行

1. 侧边栏 🛒 任务数 = 3, 点 重置 (清干净计数)
2. 点 ▶ 开始
3. 等 30-60 秒跑完

## 预期日志 (service worker Console)

```
[TSCLB-SW] START runId=run-2026...  tab=xxx  taskCount=3
[TSCLB-SW] list_batch items=N  queued=N  queue=N/3
[TSCLB-SW] list DONE raw=N cap=3 queue=3
[TSCLB-SW] runDetailLoop start queue=3
[TSCLB-SW] --- detail 1/3 @<handle1> ---
[TSCLB-SW] CLICK_ROW @<handle1>  -> <tabId>
[TSCLB-SW] detail tab <newTabId> @<handle1>
[TSCLB-SW] wait tab <newTabId>
[TSCLB-SW] tab loaded, sleeping 600ms
[TSCLB-SW] SCAN_DETAIL_NOW try 1
[TSCLB-SW] scraped @<handle1>
[TSCLB-SW] closed tab <newTabId>
... (handle2, handle3)
[TSCLB-SW] ALL DONE list=3 ok=3 fail=0
```

## 预期网络 (service worker Network, filter 8000)

跑前 (idle):
- 每 30 秒一条 POST /api/local/extension/launcher-heartbeat -> 200

跑中:
- 列表阶段: 3 条 POST /api/local/collector/observations -> 200 (体积小, 1-5KB)
- 详情阶段: 3 条 POST /api/local/collector/observations -> 200 (体积大, 100KB - 1.5MB)

## 验证清单

### V1. 列表 payload 字段完整性

抓任意一条列表 POST -> Request Payload (JSON), 对照 samples/01_list_observation_sample.json:

- [ ] event_type, platform, source, worker_id, run_id, lead_status="shop_list_seen" 都有
- [ ] creator.handle 是合法 handle (小写, 2-40字符, 含字母)
- [ ] creator.profile_url == "https://www.tiktok.com/@" + handle
- [ ] tiktok_shop.list_item.row_index 单调
- [ ] tiktok_shop.list_item.card_visible_text 非空, 含 handle 和粉丝数原文
- [ ] tiktok_shop.list_item.gmv_raw / gpm_raw / category_text / invite_status 至少有几个有值
  (note: 这几个字段是 best-effort 解析, 个别行匹配不到给 null 是正常的)

### V2. 详情 payload raw_* 字段

抓任意一条详情 POST -> Request Payload:

- [ ] lead_status="shop_profile_collected"
- [ ] creator.shop_profile_url 是 /connection/creator/detail?... 形式
- [ ] tiktok_shop.raw_visible_text 非空, 字数远大于 1000
- [ ] tiktok_shop.raw_visible_text 在 Similar creators 之前被切掉 (搜该字串应该找不到)
- [ ] tiktok_shop.raw_dom_html 非空, 体积通常 200KB - 1.5MB
- [ ] tiktok_shop.raw_capture.links 是数组, 含若干 tiktok.com 链接

### V3. 时序与重试

Console 验证:
- [ ] 每个 handle 完整经过: CLICK_ROW -> detail tab -> wait tab -> sleep 600ms -> SCAN_DETAIL_NOW -> scraped -> closed tab
- [ ] 详情失败时, "SCAN_DETAIL_NOW try 2" / "try 3" 出现 (3 次重试)
- [ ] 单个 handle 失败不影响下一个 (detailFail 计数 +1, 继续)
- [ ] 详情间隔 sleep(800 + 0-500ms)

UI 验证:
- [ ] pill 流转: 闲置 -> 运行中 -> 已完成
- [ ] "阶段：详情逐个采集中 · 详情 X/3 · 剩余 N" 实时更新
- [ ] 跑完 Chrome 系统通知弹出: "TikTok Shop 采集完成 · 列表 3 · 已提取 3/3"

### V4. X9 心跳

闲置时 service worker Network filter `launcher-heartbeat`:
- [ ] 每 30 秒一条
- [ ] payload activeTab.url 是当前 tab URL
- [ ] payload counts / settings / latestLog 都有
- [ ] reason 字段在 alarm / installed / startup / storage_change 之间

## 异常应对

| 现象 | 处理 |
|---|---|
| 列表 POST 4xx | 检查后端 schema 是否兼容当前 platform="tiktok_shop" |
| 详情 POST body too large (413) | 后端调大 max_body_size, 或前端调小 trimTo 上限 |
| detailFail 全失败 | TikTok Shop 改了 DOM 选择器, 看 shop_collector.js findHandle / detailHandle |
| 心跳一直 404 | 后端没注册 /api/local/extension/launcher-heartbeat 路由 |
