# TikTok Creator Lead Browser v2.2 — 工作流程

## 端点总览

| 通道 | 端点 | 触发 | 频率 |
|---|---|---|---|
| Shop 列表上传 | POST 127.0.0.1:8000/api/local/collector/observations | 每发现一条新 handle | 列表阶段实时, 每条独立 |
| Shop 详情上传 | POST 127.0.0.1:8000/api/local/collector/observations | 每个详情页采集完 | 详情阶段, 间隔 0.8-1.3s |
| X9 心跳 | POST {base}/api/local/extension/launcher-heartbeat | chrome.alarms + storage 变化 | 30 秒 + 触发 |
| X9 leads ingest | POST {base}/api/local/extension/...  | leads 表新增 | storage 变化 |

X9 base 自动探测顺序: localhost:8000 -> 127.0.0.1:8000 -> usx9.us -> 192.168.1.171:8000 -> 192.168.1.171

## 数据流

```
列表页 (affiliate-us/connection/creator)
   |
   |  contentScript.js + shop_collector.js
   |
   v
Service Worker (x9_sw.js)
   |
   +-- background.js     初始化 storage / 点图标开 sidePanel
   +-- x9_relay.js       30s 心跳上行 X9
   +-- shop_runner.js    Shop 状态机: 列表 -> 详情 -> 上传
   |
   v
popup.html / sidepanel.html (UI)
   |
   v
POST JSON -> 本地后端 127.0.0.1:8000
```

## 状态机 (shop_runner.js)

```
idle
  | SHOP_START (需当前 tab 在 affiliate-us / seller-us)
  v
list_scanning
  | 列表阶段, 一边滚一边发 list POST
  | CS_LIST_DONE
  v
detail_scanning
  | 队列里每个 handle:
  |   CLICK_ROW -> 等新 tab -> waitForTabComplete -> sleep 600ms
  |   SCAN_DETAIL_NOW (最多 3 次重试) -> 发 detail POST -> 关 tab
  |   sleep 0.8-1.3s
  v
finished
```

任何阶段 SHOP_STOP -> paused; 异常 -> error。

## 安装

1. chrome://extensions 开发者模式
2. 加载已解压的扩展程序 -> 选 extension/ 目录
   (或先把 extension/ 里的内容用 x9-tk-creator-extension-2.2.zip 解压出来)

## 使用

1. 后端先起: `start_desktop.bat` -> 127.0.0.1:8000
2. Chrome 登 https://affiliate-us.tiktok.com/connection/creator
3. 点扩展图标 -> 侧边栏 🛒 TikTok Shop 全自动
4. 任务数填 N, 点 ▶ 开始
5. 等列表 + 详情两阶段都跑完
6. 去 http://localhost:8000/ui/ TIKTOK全自动采集监控 tab 看数据

## 排错

| 现象 | 原因 |
|---|---|
| active_tab_is_not_tiktok_shop | 当前 tab 不在 affiliate-us / seller-us |
| detail_tab_did_not_open_in_15000ms | 行被虚拟滚动回收 / handle 文本元素改了 |
| detail_scrape_failed:detail_handle_not_found | 详情页 span.text-head-l 选择器失效 |
| upload:xxx: HTTP 4xx | 后端 schema 校验拒绝 (常见: handle 不合法) |
| upload:xxx: HTTP 5xx | 后端没起 / endpoint 错 |
| pill 卡在运行中 | 列表 tab 被关 / SW 崩 -> 看 service worker Console |

## 安全/合规边界 (代码硬约束)

- 不点赞 / 不评论 / 不关注 / 不私信 / 不发帖
- 不绕验证码 / 不用代理
- 只采页面已加载、肉眼可见的内容
- 单线程, 不并发开 tab, 滚屏随机化 0.95-1.35s, 详情间隔 0.8-1.3s
