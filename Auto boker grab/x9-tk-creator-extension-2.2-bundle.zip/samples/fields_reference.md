# 上传字段速查表

## 1. POST /api/local/collector/observations  (Shop 列表阶段)

每滚一屏发现新 handle 立刻发，每条独立一个请求。

| 路径 | 类型 | 来源 | 必有? |
|---|---|---|---|
| event_type | string | 常量 "creator_observation" | 是 |
| platform | string | 常量 "tiktok_shop" | 是 |
| source | string | settings.source 常量 | 是 |
| worker_id | string | settings.workerId 常量 | 是 |
| run_id | string | "run-" + 时间戳 | 是 |
| lead_status | string | 常量 "shop_list_seen" | 是 |
| collected_at | ISO8601 | 采集瞬间时间 | 是 |
| creator.handle | string | 行内 span.text-body-m-medium 文本 | 是 (后端会校验) |
| creator.display_name | string | 行内非 handle 的第一条文本 | 否 |
| creator.profile_url | url | `https://www.tiktok.com/@{handle}` | 是 |
| creator.shop_profile_url | url \| null | 列表阶段恒为 null | 否 |
| creator.avatar_url | url | 行内首个非 data: 的 img.src | 否 |
| creator.followers_raw | string | "12.3K" 之类 | 否 |
| creator.followers_count | number \| null | 列表阶段恒为 null | 否 |
| tiktok_shop.list_item.* | object | 与 creator 重复，加 gmv/gpm/category/invite/save/row_index/card_visible_text/card_html/card_json/source_page_url/collected_at | 是 |

## 2. POST /api/local/collector/observations  (Shop 详情阶段)

每个 handle 一条，前端不做结构化解析，原样回传整页。

| 路径 | 类型 | 来源 | 备注 |
|---|---|---|---|
| event_type | string | "creator_observation" | |
| platform | string | "tiktok_shop" | |
| source / worker_id / run_id | string | 同列表 | |
| lead_status | string | "shop_profile_collected" | |
| collected_at | ISO8601 | | |
| creator.handle | string | `span.text-head-l` 文本 或 document.title 前缀 | |
| creator.display_name | string | 详情头部其他文本节点 | |
| creator.profile_url | url | `https://www.tiktok.com/@{handle}` | |
| creator.shop_profile_url | url | location.href | 详情页 URL |
| creator.avatar_url | url | 详情页首个 img.src | |
| creator.followers_raw | string | 详情可见文本里 followers 附近的数字 | |
| tiktok_shop.source_page_url | url | location.href | |
| tiktok_shop.raw_capture.page_title | string | document.title | |
| tiktok_shop.raw_capture.page_type | string | "creator_detail" | |
| tiktok_shop.raw_capture.captured_at | ISO8601 | | |
| tiktok_shop.raw_capture.links | string[] | 去重后所有 `<a href>`, 最多 300 条 | |
| tiktok_shop.raw_visible_text | string | document.body.innerText, 已切掉 Similar creators 之后, 最多 300000 字 | 体积可观 |
| tiktok_shop.raw_dom_html | string | documentElement.outerHTML, 最多 1,500,000 字 | 体积最大, 可能 1MB+/条 |

## 3. POST /api/local/extension/launcher-heartbeat  (X9 心跳)

频率: chrome.alarms 每 30 秒 + storage 变化时。

| 路径 | 类型 | 备注 |
|---|---|---|
| app | string | "tiktok-creator-lead-browser" |
| version | string | chrome.runtime.getManifest().version |
| source | string | "x9_relay" |
| reason | string | alarm / installed / startup / storage_change |
| extensionId | string | chrome.runtime.id |
| time | ISO8601 | |
| activeTab.id / title / url / isTikTok | mixed | 当前活动标签页信息 |
| page | string | creator_list / creator_detail / other |
| counts.leads / pending / skipped / sourceVideos / taskLogs | number | 老 X9 流程的累计计数 |
| runTimer | object | 计时器状态 |
| settings | object | autoSettings + leadFilters 合并后的设置 |
| latestLog | object | 最近一条 taskLogs |

## 4. X9 leads ingest  (来自 www.tiktok.com 老流程, 非 Shop)

只有 hasDirectContact (email 或外链) 才发, 否则丢弃。skipped 走另一路径并多一个 reason 字段。

字段见 04_x9_leads_ingest_sample.json。

## 容量提醒

| 字段 | 单条上限 | 在意流量时改哪 |
|---|---|---|
| card_visible_text | 5,000 字 | shop_collector.js `trimTo(text, 5000)` |
| card_html | 40,000 字 | shop_collector.js `trimTo(row.outerHTML, 40000)` |
| raw_visible_text | 300,000 字 | shop_collector.js `trimTo(fullVisibleText, 300000)` |
| raw_dom_html | 1,500,000 字 | shop_collector.js `trimTo(... , 1500000)` |
| raw_capture.links | 300 条 | shop_collector.js `collectRawLinks().slice(0, 300)` |
